package com.example.tekdokunusceviri;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

public class FloatingService extends Service {
    WindowManager wm; View bubble; WindowManager.LayoutParams params;
    int startX,startY; float touchX,touchY;
    int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    @Override public void onCreate(){
        super.onCreate();
        if(!Settings.canDrawOverlays(this)){stopSelf();return;}
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        TextView t=new TextView(this); t.setText("Çevir"); t.setTextSize(13); t.setTextColor(Color.WHITE); t.setGravity(Gravity.CENTER); t.setPadding(dp(13),dp(9),dp(13),dp(9));
        GradientDrawable d=new GradientDrawable();d.setColor(Color.rgb(102,87,232));d.setCornerRadius(dp(28));t.setBackground(d);
        bubble=t;
        params=new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,
          WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.START;params.x=dp(18);params.y=dp(180);
        t.setOnTouchListener((v,e)->{
            switch(e.getAction()){
                case MotionEvent.ACTION_DOWN: startX=params.x;startY=params.y;touchX=e.getRawX();touchY=e.getRawY();return true;
                case MotionEvent.ACTION_UP:
                    if(Math.abs(e.getRawX()-touchX)<dp(8)&&Math.abs(e.getRawY()-touchY)<dp(8)){
                        Intent i=new Intent(this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_SINGLE_TOP);startActivity(i);
                    } return true;
                case MotionEvent.ACTION_MOVE: params.x=startX+(int)(e.getRawX()-touchX);params.y=startY+(int)(e.getRawY()-touchY);wm.updateViewLayout(bubble,params);return true;
            } return true;
        });
        wm.addView(bubble,params);
    }
    @Override public int onStartCommand(Intent i,int flags,int id){return START_STICKY;}
    @Override public void onDestroy(){if(wm!=null&&bubble!=null)try{wm.removeView(bubble);}catch(Exception ignored){}super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}