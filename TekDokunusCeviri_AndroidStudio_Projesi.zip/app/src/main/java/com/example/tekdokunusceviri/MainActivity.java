package com.example.tekdokunusceviri;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.widget.*;
import org.json.JSONObject;
import java.net.*;
import java.io.*;
import java.net.URLEncoder;

public class MainActivity extends Activity {
    EditText input;
    TextView translated, backTranslated, status;
    Spinner source, target;
    Button translateBtn, backBtn, copyBtn;
    String[] names = {"Otomatik algıla", "Türkçe", "İngilizce", "Ukraynaca", "Lehçe", "Rusça", "Almanca", "Fransızca", "İspanyolca", "İtalyanca", "Portekizce", "Arapça", "Japonca", "Korece", "Çince"};
    String[] codes = {"auto", "tr", "en", "uk", "pl", "ru", "de", "fr", "es", "it", "pt", "ar", "ja", "ko", "zh"};
    String lastTranslation = "";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(247,247,252));
        getWindow().setNavigationBarColor(Color.rgb(247,247,252));
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        buildUi();
    }

    int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + .5f); }
    TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t;
    }
    GradientDrawable bg(int color, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke); return d;
    }
    LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    LinearLayout.LayoutParams lp(int w,int h) { return new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h)); }
    void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = column(); root.setPadding(dp(20),dp(22),dp(20),dp(28)); root.setBackgroundColor(Color.rgb(247,247,252));
        scroll.addView(root); setContentView(scroll);
        TextView title=text("Tek Dokunuş Çeviri",25,Color.rgb(28,27,43)); title.setTypeface(null,1); root.addView(title);
        TextView sub=text("Çevir • geri kontrol et • kopyala",14,Color.rgb(105,103,126)); LinearLayout.LayoutParams sm=lp(-2,-2); sm.topMargin=dp(5); root.addView(sub,sm);
        Button overlay = new Button(this); overlay.setText("●  EKRAN ÜSTÜ BALONU AÇ"); overlay.setAllCaps(false);
        overlay.setTextColor(Color.WHITE); overlay.setBackground(bg(Color.rgb(102,87,232),16,0));
        LinearLayout.LayoutParams op=lp(-1,52); op.topMargin=dp(20); root.addView(overlay,op);
        overlay.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()));
                startActivity(i);
                Toast.makeText(this,"İzin ekranında uygulamanın üstünde gösterme iznini aç, sonra geri dön.",Toast.LENGTH_LONG).show();
            } else {
                startService(new Intent(this,FloatingService.class));
                Toast.makeText(this,"Balon açıldı. Diğer uygulamalara geçebilirsin.",Toast.LENGTH_SHORT).show();
            }
        });
        root.addView(text("Mesajın",16,Color.rgb(44,42,61)), top(20));
        input = new EditText(this); input.setHint("Çevirmek istediğin metni buraya yaz veya yapıştır"); input.setTextSize(16);
        input.setGravity(Gravity.TOP|Gravity.START); input.setMinLines(3); input.setPadding(dp(14),dp(12),dp(14),dp(12));
        input.setBackground(bg(Color.WHITE,14,Color.rgb(224,222,239))); root.addView(input,lp(-1,120));
        LinearLayout langs = new LinearLayout(this); langs.setOrientation(LinearLayout.HORIZONTAL);
        source = new Spinner(this); target = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, names);
        source.setAdapter(adapter); target.setAdapter(adapter); source.setSelection(0); target.setSelection(1);
        langs.addView(source,new LinearLayout.LayoutParams(0,dp(52),1)); langs.addView(target,new LinearLayout.LayoutParams(0,dp(52),1));
        root.addView(langs,top(8));
        translateBtn = new Button(this); translateBtn.setText("ÇEVİR"); translateBtn.setAllCaps(false);
        translateBtn.setTextColor(Color.WHITE); translateBtn.setBackground(bg(Color.rgb(102,87,232),14,0)); root.addView(translateBtn,top(6));
        translated = text("Çeviri burada görünecek",16,Color.rgb(39,37,56)); translated.setPadding(dp(14),dp(14),dp(14),dp(14)); translated.setBackground(bg(Color.WHITE,14,Color.rgb(224,222,239))); root.addView(translated,top(8));
        backBtn = new Button(this); backBtn.setText("↶  TÜRKÇEYE GERİ ÇEVİR VE KONTROL ET"); backBtn.setAllCaps(false); root.addView(backBtn,top(8));
        backTranslated = text("Geri çeviri burada görünecek",16,Color.rgb(39,37,56)); backTranslated.setPadding(dp(14),dp(14),dp(14),dp(14)); backTranslated.setBackground(bg(Color.WHITE,14,Color.rgb(224,222,239))); root.addView(backTranslated,top(8));
        copyBtn = new Button(this); copyBtn.setText("KOPYALA"); copyBtn.setAllCaps(false); root.addView(copyBtn,top(4));
        status = text("Geri çeviri anlamı kontrol etmeye yardımcı olur; kusursuzluk garantisi değildir.",12,Color.rgb(105,103,126)); root.addView(status,top(10));
        translateBtn.setOnClickListener(v -> doTranslate());
        backBtn.setOnClickListener(v -> doBackTranslate());
        copyBtn.setOnClickListener(v -> {
            String s = lastTranslation.isEmpty() ? translated.getText().toString() : lastTranslation;
            if (s.isEmpty() || s.equals("Çeviri burada görünecek")) { Toast.makeText(this,"Önce çeviri yap.",Toast.LENGTH_SHORT).show(); return; }
            ((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Çeviri",s));
            Toast.makeText(this,"Çeviri kopyalandı.",Toast.LENGTH_SHORT).show();
        });
    }
    LinearLayout.LayoutParams top(int n) { LinearLayout.LayoutParams p=lp(-1,-2); p.topMargin=dp(n); return p; }
    String codeAt(Spinner s) { int i=s.getSelectedItemPosition(); return codes[Math.max(0,Math.min(i,codes.length-1))]; }
    void doTranslate() {
        String q=input.getText().toString().trim(); if(q.isEmpty()){input.setError("Önce bir metin yaz.");return;}
        String from=codeAt(source), to=codeAt(target);
        if(from.equals("auto")) from=detect(q);
        if(from.equals(to)){ status.setText("Kaynak ve hedef dili farklı seç."); return; }
        final String f=from, t=to;
        status.setText("Çevriliyor…"); translateBtn.setEnabled(false);
        new Thread(() -> {
            try { String result=api(q,f,t); runOnUiThread(() -> {lastTranslation=result;translated.setText(result);status.setText("Çeviri tamamlandı. İstersen Türkçeye geri çevir.");translateBtn.setEnabled(true);}); }
            catch(Exception e){runOnUiThread(() -> {status.setText("Çeviri yapılamadı. İnternet bağlantını kontrol edip tekrar dene.");translateBtn.setEnabled(true);});}
        }).start();
    }
    void doBackTranslate() {
        String q=lastTranslation;
        if(q.isEmpty()){Toast.makeText(this,"Önce metni çevir.",Toast.LENGTH_SHORT).show();return;}
        String targetCode=codeAt(target);
        String sourceCode=codeAt(source);
        if(sourceCode.equals("auto")) sourceCode="tr";
        final String from=targetCode, to=sourceCode.equals("tr")?"tr":sourceCode;
        backBtn.setEnabled(false); status.setText("Geri çeviri kontrol ediliyor…");
        new Thread(() -> {
            try { String result=api(q,from,to); runOnUiThread(() -> {backTranslated.setText(result);status.setText("Sonucu ilk mesajınla karşılaştır. Anlam nüansları değişebilir.");backBtn.setEnabled(true);}); }
            catch(Exception e){runOnUiThread(() -> {status.setText("Geri çeviri başarısız. Bağlantını kontrol et.");backBtn.setEnabled(true);});}
        }).start();
    }
    String detect(String q) {
        // Simple UI fallback: use Turkish as source only when it contains common Turkish characters.
        String lower=q.toLowerCase();
        if(lower.matches(".*[çğıöşü].*") || lower.matches(".*\\\\b(ve|bir|ben|sen|çok|için|ama)\\\\b.*")) return "tr";
        return "en";
    }
    String api(String q,String from,String to) throws Exception {
        String url="https://api.mymemory.translated.net/get?q="+URLEncoder.encode(q,"UTF-8")+"&langpair="+URLEncoder.encode(from+"|"+to,"UTF-8");
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection(); c.setRequestMethod("GET"); c.setConnectTimeout(12000); c.setReadTimeout(15000);
        try {
            InputStream is=(c.getResponseCode()<400)?c.getInputStream():c.getErrorStream();
            ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] buf=new byte[4096]; int n; while((n=is.read(buf))>0)out.write(buf,0,n);
            JSONObject obj=new JSONObject(new String(out.toByteArray(),"UTF-8"));
            String response=obj.optJSONObject("responseData").optString("translatedText","");
            if(response.isEmpty()) throw new Exception("empty"); return android.text.Html.fromHtml(response,android.text.Html.FROM_HTML_MODE_LEGACY).toString();
        } finally { c.disconnect(); }
    }
}