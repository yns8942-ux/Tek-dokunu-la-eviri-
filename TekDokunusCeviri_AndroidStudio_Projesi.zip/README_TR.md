# Tek Dokunuş Çeviri — Android proje dosyaları

Bu klasör Android Studio ile APK oluşturmak için kaynak projedir; bu ortamda Android SDK/Gradle bulunmadığından derlenmiş APK değildir.

## Özellikler
- Diğer uygulamaların üzerinde sürüklenebilir “Çevir” balonu
- Metin yazma/yapıştırma
- Çeviri ve geri çeviri kontrolü
- Son çeviriyi panoya kopyalama
- Türkçe arayüz ve seçilebilir dil çiftleri

## APK oluşturma
1. Bilgisayara Android Studio kur: https://developer.android.com/studio
2. Android Studio > Open ile `TekDokunusCeviri` klasörünü aç.
3. Gradle senkronizasyonu tamamlanınca Build > Build APK(s) seç.
4. APK genellikle `app/build/outputs/apk/debug/app-debug.apk` yolunda oluşur.
5. APK'yı telefona aktar ve aç. Android bilinmeyen uygulama yükleme izni isterse yalnızca bu APK için izin ver.

## Telefonda kullanım
1. Uygulamayı aç.
2. “Ekran üstü balonu aç” düğmesine dokun ve diğer uygulamaların üzerinde gösterme iznini etkinleştir.
3. Uygulamaya geri dön ve düğmeye tekrar bas.
4. “Çevir” balonunu istediğin yere sürükle; dokununca çeviri ekranı açılır.

## Çeviri hakkında
Çeviri hizmeti MyMemory'nin çevrimiçi API'sini kullanır; internet gerekir ve dil çiftleri/hizmet kotası değişebilir. “Otomatik algıla” bu ilk sürümde basit bir sezgisel algılama kullanır; her dili kesin tanımaz. Daha iyi sonuç için kaynak dili listeden seç. Geri çeviri, anlam kontrolüne yardımcı olur ancak birebir doğruluk garantisi değildir. Metin, çeviri sağlayıcısına gönderilir; özel mesajlar için bunu dikkate al.

## Sınırlar
Bu ilk sürüm, başka uygulamalardaki yazıyı kendiliğinden okuyup seçmez. Balon çeviri ekranını açar; metni kutuya yapıştırman gerekir. Otomatik ekran OCR'si ve panodan kendiliğinden alma sonraki sürümde eklenebilir.
